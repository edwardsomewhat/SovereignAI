---
name: agent-tool-response-patterns
description: >-
  Rules for handling tool call responses in CLI agent context. Ensures non-empty, meaningful responses after every tool invocation.
category: software-development
---

# Agent Tool Response Patterns

## When to Use
After every tool call (memory, skill_manage, skill_view, etc.) in a CLI agent context. This skill ensures the agent always produces a meaningful text response.

## Core Rule: NEVER Return Empty After Tool Calls

After a tool executes, ALWAYS respond with substantive text:
- Simple greeting: "Hello! How can I help?"
- Tool success: Acknowledge + next steps
- Tool failure: Explain error + propose alternative
- Multiple tools: Synthesize coherently

## Memory Tool Quirks
- `replace` requires BOTH `old_text` AND `content` parameters
- Missing `content` = tool failure with "content is required"
- Use `add` for new entries, `replace` to update, `remove` to delete (old_text only)
- If unsure, `add` is safer than `replace`

## Vision Tool Limitations
- `vision_analyze` works ONLY with image files (png, jpg, gif, bmp, etc)
- Fails on audio/video/text files with "Only real image files are supported"
- Do not attempt vision analysis on non-image media

## Clarify Tool Behavior
- `clarify` returns timeout if no user response within limit
- Handle gracefully: proceed with best judgment

## Response Pattern
Always follow this pattern after tool calls:
1. Acknowledge what happened (success/failure)
2. Provide brief context if relevant
3. Offer next steps or ask what to do next

## Pitfalls
- Do not return empty responses - this triggers system retries
- Do not chain tool calls without responding between them
- Memory `replace` is finicky - prefer `add` for simple cases
- Vision tools are image-only - do not misuse for other media types