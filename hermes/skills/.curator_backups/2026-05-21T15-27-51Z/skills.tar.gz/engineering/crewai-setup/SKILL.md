---
name: crewai-setup
description: Build and configure CrewAI 1.x multi-agent systems — hierarchical crews, YAML-based agent/task configs, OpenRouter LLM wiring, common pitfalls. Use when the user says "build a crew", "set up CrewAI", "create a multi-agent system", "orchestrate agents", or describes a swarm/squad of AI agents that need a coordinator.
---

# CrewAI Setup

Build CrewAI multi-agent crews from scratch. Covers 1.x API (≥1.14): YAML configs, `@CrewBase` decorator, hierarchical process, OpenRouter as LLM backend.

## Prerequisites

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install crewai crewai-tools python-dotenv
pip install -e .              # install project package in editable mode
```

## Project Structure

```
project/
├── .venv/
├── .env                  # API keys (OPENROUTER_API_KEY, etc.)
├── pyproject.toml
├── .gitignore
└── src/
    └── crew_package/
        ├── __init__.py
        ├── main.py
        ├── crew.py        # @CrewBase class
        └── config/
            ├── agents.yaml
            └── tasks.yaml
```

## Step 1 — agents.yaml

Each agent gets a named block with `role`, `goal`, `backstory`:

```yaml
researcher:
  role: "Senior Researcher"
  goal: "Find and synthesize information on {topic}"
  backstory: >
    You are a meticulous researcher with deep domain knowledge.
    You leave no stone unturned.
```

CrewAI replaces `{variable}` placeholders from `kickoff(inputs={...})`.

## Step 2 — tasks.yaml

Each task block: `description`, `expected_output`, `agent` (name matching agent key):

```yaml
research_task:
  description: "Research {topic} thoroughly"
  expected_output: "A list of 10 key findings"
  agent: researcher
```

## Step 3 — crew.py with @CrewBase

```python
import os
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from dotenv import load_dotenv

load_dotenv()

def _get_llm(model_override=None):
    model = model_override or os.getenv("CREW_MODEL", "deepseek/deepseek-chat")
    return f"openrouter/{model}"

@CrewBase
class MyCrew:
    agents_config = "config/agents.yaml"
    tasks_config = "config/tasks.yaml"

    @agent
    def researcher(self) -> Agent:
        return Agent(config=self.agents_config["researcher"], llm=_get_llm())

    @task
    def research_task(self) -> Task:
        return Task(config=self.tasks_config["research_task"])

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=[self.researcher(), self.writer()],   # call each method explicitly
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
        )
```

## Step 4 — Hierarchical Crew (Manager + Workers)

For hierarchical mode, the manager is SEPARATE from the worker agent list:

```python
@crew
def crew(self) -> Crew:
    supervisor = self.supervisor()   # manager agent
    workers = [                      # NOT including supervisor
        self.researcher(),
        self.writer(),
    ]
    return Crew(
        agents=workers,
        tasks=self.tasks,
        process=Process.hierarchical,
        manager_agent=supervisor,
        manager_llm=f"openrouter/{os.getenv('MANAGER_MODEL', 'anthropic/claude-sonnet-4')}",
        verbose=True,
        planning=True,
        memory=True,
    )
```

## Step 5 — OpenRouter LLM Wiring

Use the `openrouter/` prefix with LiteLLM:

```python
from crewai import LLM

llm = LLM(
    model="openrouter/deepseek/deepseek-chat",
    api_key=os.getenv("OPENROUTER_API_KEY"),
    base_url="https://openrouter.ai/api/v1",
)
```

Or pass model string directly to `Agent(llm="openrouter/deepseek/deepseek-chat")` — CrewAI resolves API creds from env vars (`OPENROUTER_API_KEY`, `OPENROUTER_BASE_URL`).

Two-tier model strategy: weaker/cheaper model for workers, stronger model for the hierarchical manager. Set `manager_llm=` on the Crew for the manager; set `llm=` on each Agent for workers.

## Entry Point (main.py)

```python
from dotenv import load_dotenv; load_dotenv()
from crew_package.crew import MyCrew

result = MyCrew().crew().kickoff(inputs={"topic": user_input})
print(result)
```

## Pitfalls

### manager_agent must not be in agents list
In `Process.hierarchical`, if the manager agent also appears in `agents=`, CrewAI raises:
```
ValidationError: Manager agent should not be included in agents list.
```
Fix: remove the manager from the worker agents list. The manager is set via `manager_agent=` only.

### @CrewBase does not expose .agents as a list
`self.agents` is NOT available on the @CrewBase instance. Each agent is only accessible via its decorated method (e.g., `self.researcher()`). Collect workers explicitly by calling each method.

### Symlinked .env files
If `project/.env` is a symlink to a shared `.env`, writing to it overwrites the shared file. Check `ls -la` before writing. Merge new vars into existing content rather than replacing.

### YAML multiline strings
Use `>` (folded) for long descriptions — newlines become spaces. Use `|` (literal) only when you need to preserve line breaks. The `>` style is preferred for agent backstories and task descriptions.

## Verification

```bash
cd project && .venv/bin/python -c "
from dotenv import load_dotenv; load_dotenv()
from crew_package.crew import MyCrew
c = MyCrew().crew()
print(f'Process: {c.process}, Agents: {len(c.agents)}, Tasks: {len(c.tasks)}')
# For hierarchical: print(f'Manager: {c.manager_agent.role}')
"
```

See `references/api-notes.md` for field-level Agent/Task/Crew attribute tables sourced from CrewAI 1.14 docs.
